package io.keepcoding.data.simulator.streaming


import scala.concurrent.ExecutionContext.Implicits.global
import org.apache.spark.sql.types.{LongType, StringType, StructField, StructType, TimestampType}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession, functions, types}
import org.apache.spark.sql.functions.{lit, _}

import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

object AntennaStreamingJob extends StreamingJob {

  System.setProperty("hadoop.home.dir", "C:\\Hadoop");
  override val spark: SparkSession = SparkSession

    .builder()
    .master("local[20]")
    .appName("Practice  SQL Streaming")
    .getOrCreate()

  import spark.implicits._


  override def readFromKafka(kafkaServer: String, topic: String): DataFrame = {
    spark

      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", kafkaServer)
      .option("subscribe", topic)
      .load()
  }

  override def parserJsonData(dataFrame: DataFrame): DataFrame = {

    val jsonSchema = StructType(Seq(
      StructField("bytes", LongType, nullable = false),
      StructField("timestamp", TimestampType, nullable = false),
      StructField("app", StringType, nullable = false),
      StructField("id", StringType, nullable = false),
      StructField("antenna_id", StringType, nullable = false)

    ))


    dataFrame
      .select(from_json(col("value").cast(StringType), jsonSchema).as("json"))
      .select("json.*")
      //.withColumn("timestamp", $"timestamp".cast(TimestampType))
  }

  override def readDeviceMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {

    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }


  override def enrichUserWithMetadata(deviceDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    deviceDF.as("a")
      .join(
        metadataDF.as("b"),
        $"a.id" === $"b.id"
      ).drop($"b.id")
  }


  override def total_Bytes_Antenna(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(cols = $"timestamp", $"antenna_id", $"bytes")
      .withWatermark(eventTime = "timestamp", delayThreshold = "5 minutes")
      .groupBy(cols = $"antenna_id", window(timeColumn = $"timestamp", windowDuration = "2 minutes").as("window"))
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"antenna_id".as("id"), $"value", lit("total_Bytes_Antenna").as("type"))
  }

  override def total_Bytes_Users(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(cols = $"timestamp", $"id", $"bytes")
      .withWatermark(eventTime = "timestamp", delayThreshold = "5 minutes")
      .groupBy(cols = $"id", window(timeColumn = $"timestamp", windowDuration = "2 minutes").as("window"))
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"id", $"value", lit("total_Bytes_Users").as("type"))
  }

  override def total_Bytes_App(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(cols = $"timestamp", $"app", $"bytes")
      .withWatermark(eventTime = "timestamp", delayThreshold = "5 minutes")
      .groupBy(cols = ($"app").as("id"), window(timeColumn = $"timestamp", windowDuration = "2 minutes").as("window"))
      .agg(sum($"bytes").as("value"))
      .select($"window.start".as("timestamp"), $"id", $"value", lit("total_Bytes_app").as("type"))

  }

  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit] = Future {
    dataFrame
      .writeStream
      .foreachBatch {
        (batch: DataFrame, _: Long) => {
          batch
            .write
            .mode(SaveMode.Append)
            .format("jdbc")
            .option("url", jdbcURI)
            .option("dbtable", jdbcTable)
            .option("user", user)
            .option("password", password)
            .save()
        }
      }
      .start()
      .awaitTermination()
  }

  override def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit] = Future {
    dataFrame
      .select(
        $"timestamp", $"id", $"antenna_id", $"bytes", $"app",
        year($"timestamp").as("year"),
        month($"timestamp").as("month"),
        dayofmonth($"timestamp").as("day"),
        hour($"timestamp").as("hour"),
      )
      .writeStream
      .format("parquet")
      .option("path", s"$storageRootPath\\data")
      .option("checkpointLocation", s"$storageRootPath\\checkpoint")
      .partitionBy("year", "month", "day", "hour")
      .start
      .awaitTermination()
  }

  def main(args: Array[String]): Unit = {

    val kafkaDF = readFromKafka("34.88.112.133:9092", "devices")
    val parseDF = parserJsonData(kafkaDF)
    val storageFuture = writeToStorage(parseDF, storageRootPath = "/temp/device_parquet/")
    val metadataDF = readDeviceMetadata(
      "jdbc:postgresql://34.155.89.109:5432/postgres",
      "user_metadata",
      "postgres",
      "keepcoding"
    )
    val enrichDF = enrichUserWithMetadata(parseDF, metadataDF)
    val antenna_Bytes = total_Bytes_Antenna(enrichDF)
    val users_Bytes = total_Bytes_Users(enrichDF)
    val app_Bytes = total_Bytes_App(enrichDF)
    val jdbcFuture = writeToJdbc(antenna_Bytes, "jdbc:postgresql://34.155.89.109/postgres", jdbcTable = "bytes", user = "postgres", password = "keepcoding") //sql
    val jdbcFuture1 = writeToJdbc(users_Bytes, "jdbc:postgresql://34.155.89.109:5432/postgres", jdbcTable = "bytes", user = "postgres", password = "keepcoding")
    val jdbcFuture2 = writeToJdbc(app_Bytes, "jdbc:postgresql://34.155.89.109:5432/postgres", jdbcTable = "bytes", user = "postgres", password = "keepcoding")


    Await.result(Future.sequence(Seq(storageFuture, jdbcFuture, jdbcFuture1, jdbcFuture2)), Duration.Inf)

    spark.close()

  }


}
