package io.keepcoding.data.simulator.batch


import java.sql.Timestamp
import java.time.OffsetDateTime
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}
import org.apache.spark.sql.{DataFrame, SparkSession}


case class AntennaMessage(year: Int, month: Int, day: Int, hour: Int, timestamp: Timestamp, id: String, metric: String, value: Long)

trait BatchJob {

  val spark: SparkSession

  def readFromStorage(storagePath: String, filterDate: OffsetDateTime): DataFrame

  def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame

  def enrichDeviceWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame

  def total_Bytes_For_Antenna(dataFrame: DataFrame): DataFrame

  def total_Bytes_From_Email(dataFrame: DataFrame): DataFrame

  def total_Bytes_From_App (dataFrame:  DataFrame):DataFrame

  def users_Exceed_Quota(dataFrame: DataFrame): DataFrame

  def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit

  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Unit

  def run(args: Array[String]): Unit = {
    val Array(filterDate, storagePath, jdbcUri, jdbcMetadataTable, aggJdbcTable, aggJdbcErrorTable, aggJdbcPercentTable, jdbcUser, jdbcPassword) = args
    println(s"Running with: ${args.toSeq}")

    val antennaDF = readFromStorage(storagePath, OffsetDateTime.parse(filterDate))
    val metadataDF = readAntennaMetadata(jdbcUri, jdbcMetadataTable, jdbcUser, jdbcPassword)
    val DeviceMetadataDF = enrichDeviceWithMetadata(antennaDF, metadataDF).cache()
    val antennaDF_Total = total_Bytes_For_Antenna(DeviceMetadataDF)
    val emailDF_Total = total_Bytes_From_Email(DeviceMetadataDF)
    val appDF_Total = total_Bytes_From_App(DeviceMetadataDF)
    val exceedDF_Quota = users_Exceed_Quota(DeviceMetadataDF)


    writeToJdbc(antennaDF_Total, jdbcUri, aggJdbcTable, jdbcUser, jdbcPassword)
    writeToJdbc(emailDF_Total, jdbcUri, aggJdbcPercentTable, jdbcUser, jdbcPassword)
    writeToJdbc(appDF_Total, jdbcUri, aggJdbcErrorTable, jdbcUser, jdbcPassword)
    writeToJdbc(exceedDF_Quota, jdbcUri, aggJdbcErrorTable, jdbcUser, jdbcPassword)

    writeToStorage(antennaDF, storagePath)

    spark.close()
  }

}
