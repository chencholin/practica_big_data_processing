package io.keepcoding.data.simulator.batch


import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import java.time.OffsetDateTime


object AntennaBatchJob extends BatchJob {

  override val spark: SparkSession = SparkSession
    .builder()
    .master("local[*]")
    .appName("Exercise SQL Batch : Sebastian Benitez Hurtado")
    .getOrCreate()

  import spark.implicits._

  override def readFromStorage(storagePath: String, filterDate: OffsetDateTime): DataFrame = {
    spark
      .read
      .format("parquet")
      .load(s"${storagePath}/data")
      .filter(
        $"year" === filterDate.getYear &&
          $"month" === filterDate.getMonthValue &&
          $"day" === filterDate.getDayOfMonth &&
          $"hour" === filterDate.getHour
      )
  }

  override def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .load()
  }
  override def enrichDeviceWithMetadata(deviceDF: DataFrame, metadataDF: DataFrame): DataFrame = {
    deviceDF.as("a")
      .join(
        metadataDF.as("b"),
        $"a.id" === $"b.id"
      ).drop($"b.id")
  }


  override def total_Bytes_For_Antenna(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(cols = $"timestamp", $"antenna_id", $"bytes")
      .groupBy(cols = $"antenna_id", window(timeColumn = $"timestamp", windowDuration = "1 hour").as("window"))
      .agg(
        sum($"bytes").as("value")
      )
      //bytes(timestamp TIMESTAMP, id TEXT, value BIGINT, type TEXT)
      .select($"window.start".as("timestamp"), $"antenna_id".as("id"), $"value", lit("antenna_total_bytes").as("type"))
  }

  override def total_Bytes_From_Email(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(cols = $"timestamp", $"email", $"bytes")
      .groupBy(cols = ($"email").as("id"), window(timeColumn = $"timestamp", windowDuration = "1 hour").as("window"))
      .agg(
        sum($"bytes").as("value")
      )
      //bytes(timestamp TIMESTAMP, id TEXT, value BIGINT, type TEXT)
      .select($"window.start".as("timestamp"), $"id", $"value", lit("user_total_bytes").as("type"))

  }

  override def total_Bytes_From_App (dataFrame:  DataFrame):DataFrame = {
    dataFrame
      .select(cols = $"timestamp", $"app", $"bytes")
      .groupBy(cols = ($"app").as("id"), window(timeColumn = $"timestamp", windowDuration = "1 hour").as("window"))
      .agg(
        sum($"bytes").as("value")
      )
      .select($"window.start".as("timestamp"), $"id", $"value", lit("app_total_bytes").as("type"))

  }

  override def users_Exceed_Quota(dataFrame: DataFrame): DataFrame = {
    dataFrame
      .select(cols = $"timestamp", $"email",$"id" ,$"bytes", $"quota")
      .groupBy(cols = $"id", $"email", $"quota",window(timeColumn = $"timestamp", windowDuration = "1 hour").as("window"))
      .agg(
      sum($"bytes").as("bytes_by_user")
    )
      .where("bytes_by_user > quota")
      .select(
        $"email".as("email"),
        $"bytes_by_user".as("usage"),
        $"quota".as("quota"),
        $"window.start".as("timestamp")
      )
  }

  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Unit = {
    dataFrame
      .write
      .mode(SaveMode.Append)
      .format("jdbc")
      .option("driver", "org.postgresql.Driver")
      .option("url", jdbcURI)
      .option("dbTable", jdbcTable)
      .option("user", user)
      .option("password", password)
      .save()
  }

  override def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Unit = {
    dataFrame
      .write
      .format("parquet")
      .option("path", s"$storageRootPath/data")
      .option("checkpointLocation", s"$storageRootPath/checkpoint")
      .partitionBy("year", "month", "day", "hour")
      .mode(SaveMode.Overwrite)
      .save(path = s"$storageRootPath/historical")
  }


  def main(args: Array[String]): Unit = {

    val offsetDateTime = OffsetDateTime.parse("2022-10-29T17:00:00Z")
    val parquetDF = readFromStorage("/tmp/proyecto/antenna_parquet", offsetDateTime)

    val metadataDF = readAntennaMetadata(
      "jdbc:postgresql://34.155.89.109:5432/postgres",
      "user_metadata",
      "postgres",
      "keepcoding"
    )


    val DeviceMetadataDF = enrichDeviceWithMetadata(parquetDF, metadataDF).cache()
    val antennaDF_Total = total_Bytes_For_Antenna(DeviceMetadataDF)
    val emailDF_Total = total_Bytes_From_Email(DeviceMetadataDF)
    val appDF_Total = total_Bytes_From_App(DeviceMetadataDF)
    val exceedDF_Quota = users_Exceed_Quota(DeviceMetadataDF)

    writeToJdbc(antennaDF_Total, "jdbc:postgresql://34.155.89.109:5432/postgres", "bytes_hourly", "postgres", "keepcoding")
    writeToJdbc(emailDF_Total, "jdbc:postgresql://34.155.89.109:5432/postgres", "bytes_hourly", "postgres", "keepcoding")
    writeToJdbc(appDF_Total, "jdbc:postgresql://34.155.89.109:5432/postgres", "bytes_hourly", "postgres", "keepcoding")
    writeToJdbc(exceedDF_Quota, "jdbc:postgresql://34.155.89.109:5432/postgres", "user_quota_limit", "postgres", "keepcoding")

    writeToStorage(parquetDF, "/tmp/proyecto/antenna_parquet")

    spark.close()


  }
}