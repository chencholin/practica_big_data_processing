package io.keepcoding.data.simulator.streaming
import io.keepcoding.data.simulator.streaming.AntennaStreamingJob.{readFromKafka, writeToStorage}
import org.apache.spark.sql.{DataFrame, SparkSession}

import java.sql.Timestamp
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

case class AntennaMessage(timestamp: Timestamp, id: String, metric: String, value: Long)

trait StreamingJob {

  val spark: SparkSession

  def readFromKafka(kafkaServer: String, topic: String): DataFrame

  def parserJsonData(dataFrame: DataFrame): DataFrame

  def readDeviceMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame

  def enrichUserWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame

  def total_Bytes_Antenna(dataFrame: DataFrame): DataFrame

  def total_Bytes_Users(dataFrame: DataFrame): DataFrame

  def total_Bytes_App(dataFrame: DataFrame): DataFrame

  def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit]

  def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit]


  def run(args: Array[String]): Unit = {
    val Array(kafkaServer, topic, jdbcUri, jdbcMetadataTable, aggJdbcTable, jdbcUser, jdbcPassword, storagePath) = args
    println(s"Running with: ${args.toSeq}")

    val kafkaDF = readFromKafka("34.88.112.133:9092", "devices")
    val parseDF = parserJsonData(kafkaDF)
    val storageFuture = writeToStorage(parseDF, storageRootPath = "d:/temp/device_parquet/")
    val metadaDF = readDeviceMetadata(
      "jdbc:postgresql://34.155.89.109:5432/postgres",
      "user_metadata",
      "postgres",
      "keepcoding"
    )
    val enrichDF = enrichUserWithMetadata(parseDF, metadaDF)
    val antenna_Bytes = total_Bytes_Antenna(enrichDF)
    val users_Bytes = total_Bytes_Users(enrichDF)
    val app_Bytes = total_Bytes_App(enrichDF)
    val jdbcFuture = writeToJdbc(antenna_Bytes, "jdbc:postgresql://34.155.89.109/postgres", jdbcTable = "bytes", user = "postgres", password = "keepcoding") //sql
    val jdbcFuture1 = writeToJdbc(users_Bytes, "jdbc:postgresql://34.155.89.109:5432/postgres", jdbcTable = "bytes", user = "postgres", password = "keepcoding")
    val jdbcFuture2 = writeToJdbc(app_Bytes, "jdbc:postgresql://34.155.89.109:5432/postgres", jdbcTable = "bytes", user = "postgres", password = "keepcoding")

    Await.result(Future.sequence(Seq(storageFuture, jdbcFuture, jdbcFuture1, jdbcFuture2)), Duration.Inf)

  }


}