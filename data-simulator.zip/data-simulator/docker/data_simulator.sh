#!/bin/bash

java -cp /data-simulator-assembly-0.1.jar io.keepcoding.data.simulator.DataSimulator $KAFKA_SERVERS